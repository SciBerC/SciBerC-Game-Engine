#ifndef MAIN_H
#define MAIN_H

#include "States/GameState.hpp"
#include "States/MenuState.hpp"
#include "State.h"

#endif // MAIN_H
