SciBerC-Game-Engine
===================

A game engine made in C++ using the SFML API Set.



Test the engine out here 
==== -> http://dl.dropbox.com/u/52325119/Games/SciBerC-Game-Engine/SciBerCGameEngine.exe