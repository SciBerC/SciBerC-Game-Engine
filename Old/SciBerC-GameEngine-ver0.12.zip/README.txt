SciBerC-Game-Engine version 0.12
===================

A game engine made in C++ using the SFML API Set.



Test the engine out here // this will always be a link to the most recent Engine.
==== -> http://dl.dropbox.com/u/52325119/Games/SciBerC-Game-Engine/SciBerCGameEngine.exe